#pragma once

#include <string>

extern bool DoMerge( const std::string& fwdPath, const std::string& revPath,
                     const std::string& mergedPath );
